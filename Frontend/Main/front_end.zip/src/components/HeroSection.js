import React from 'react';
import '../App.css';
import { Button } from './Button';
import './HeroSection.css';


function HeroSection() {
  return (
    
    <div className='hero-container'>
      <br />
      <br />
      <br />
      <br />
      <br />
      <p>What are you waiting for? Use Your Linkedn and</p>
      <div className='hero-btns'>
        <Button
          className='btns'
          buttonStyle='btn--outline'
          buttonSize='btn--large'
        >
          Build My Resume
        </Button>
        <Button
          className='btns'
          buttonStyle='btn--outline2'
          buttonSize='btn--small'
        >
          Update My resume
        </Button>
      </div>

      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
    </div>

  );
}

export default HeroSection;
