import React from 'react'

const FormSuccess = () => {
    return (
        <div>
            <h1>Welcome</h1>
        </div>
    )
}

export default FormSuccess
