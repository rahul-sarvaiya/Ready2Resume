import React from 'react';
import '../../App.css';
import Navbar from '../navbar';

export default function Products() {
  return (
    <>
    <Navbar />
    <h1 className='products'>PRODUCTS</h1>
    </>
  );
}
