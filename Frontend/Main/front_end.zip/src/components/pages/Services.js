import React from 'react';
import '../../App.css';
import Navbar from '../navbar';

export default function Services() {
  return(
    <>
    <Navbar />
    <h1 className='services'>SERVICES</h1>
    </>
  ); 
}
