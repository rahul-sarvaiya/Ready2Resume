import React, { useState, useEffect } from 'react';
import './Cards.css';
import './Button.css';
import CardItem from './CardItem';
import { Button } from './Button';
import { Link } from 'react-router-dom';
import Navbar from './navbar';

function template() {
  return (
    <>
    <Navbar/>
    <h1 className='templates'>SERVICES</h1>
    </>
  );
}

export default template;
