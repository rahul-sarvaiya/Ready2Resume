import React, { useState, useEffect } from 'react';
import './Cards.css';
import './Button.css';
import CardItem from './CardItem';
import { Button } from './Button';
import { Link } from 'react-router-dom';

function Cards() {
  return (
    <div className='cards'>
      <h1>Free Resume Templates</h1>
      <div className='cards__container'>
        <div className='cards__wrapper'>
          <ul className='cards__items'>
            <CardItem
              src='images/free_res_1.png'
              text='1'
              label='basic'
              path='/services'
            />
            <CardItem
              src='images/free_res_1.png'
              text='2'
              label='basic'
              path='/services'
            />
             <CardItem
              src='images/free_res_1.png'
              text='3'
              label='basic'
              path='/services'
            />
          </ul>
          <h1>Premium Resume Templates</h1>
          <ul className='cards__items'>
            <CardItem
              src='images/free_res_1.png'
              text='1'
              label='MPremium'
              path='/services'
            />
            <CardItem
              src='images/free_res_1.png'
              text='2'
              label='Premium'
              path='/products'
            />
            <CardItem
              src='images/free_res_1.png'
              text='3'
              label='premium'
              path='/sign-up'
            />
            <CardItem
              src='images/free_res_1.png'
              text='4'
              label='premium'
              path='/sign-up'
            />
          </ul>
        </div>
      </div>
      <div align="center">
      <a href="./template.js">
      See More Templates
      </a>
      </div>
    </div>
  );
}

export default Cards;
