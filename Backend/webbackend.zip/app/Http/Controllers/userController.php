<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Password;
class userController extends Controller
{
    //
    function register(Request $req)
    {
        $user=new User;
        $email=$req->email;
        $data=DB::select("select  email from users where email=?",[$email]);
        if(!$data)
        {
            $user->username= $req->input('username');
            $user->email= $req->input('email');
            $user->password=$req->input('password');
            $user->token=sha1(time());
            $user->save();
            return $user;
        }
        else
        {
            return ["email already exists"];
        }
    }
    function login(Request $req)
    {
        $email=$req->email;
        $pass=$req->password;
        $data=DB::select("select username , email , password from users where email=? and password=?",[$email,$pass]);
        if(!$data)
        {
            return ["email or password doesn't matched"];
        }




        return $data;

    }

}


