<center>
<h1>Hello,</h1>
<h3>No need to worry, you can reset your password by clicking the link below:</h3>
<a href="http://localhost:3000/reset/{{$token}}">Reset password</a>
<h3>Your token is: {{$token}}</h3>
    <h3>Copy this token and paste on reset password form</h3>
<h3>Thank you!</h3>
</center>
